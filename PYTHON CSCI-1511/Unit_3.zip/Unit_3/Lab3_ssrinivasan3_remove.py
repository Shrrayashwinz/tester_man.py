'''
Program Name: "Lab3_ssrinviasan3_remove"
 
Author: Shrrayash Srinivasan

Purpose: Do the usual importing but this time, eliminate 'binoculars' from the list and print out the new result.

Date: September 10, 2025
'''
# Import from project without copying and pasting
from Lab3_ssrinivasan3_replace import camping_stuff

# Remove binoculars from the list
camping_stuff.pop(2)
print((camping_stuff))

print("Binoculars has been removed from the list")
