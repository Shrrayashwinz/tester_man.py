"""
Program Name: "Lab1_ssrinivasan-#3"

Author: Shrrayash Srinivasan

Purpose of this program: The purpose of this program is to take a random string and reverse it and give the letter
count of the original string.

Date: September 4, 2025.

"""

# Get input from the use
user_message = input("Please type a message here: ")

# Reverse the string
reversed_message = user_message [::-1]

#print the reversed string on the same line
print ("Here is your reversed message:", reversed_message)

# print out the numbers in the original string
print ("The number of characters in this string is", len(user_message))





